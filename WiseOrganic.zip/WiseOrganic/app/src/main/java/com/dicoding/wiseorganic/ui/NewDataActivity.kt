package com.dicoding.wiseorganic.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.dicoding.wiseorganic.R
import com.dicoding.wiseorganic.data.response.WasteResponse
import com.dicoding.wiseorganic.data.retrofit.ApiConfig
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class NewDataActivity : AppCompatActivity() {
    private var currentPhotoUri: Uri? = null
    private var currentPhotoFile: File? = null

    // EditText for each waste category
    private lateinit var edWetOrganic: EditText
    private lateinit var edPet: EditText
    private lateinit var edAluminiumCan: EditText
    private lateinit var edTerraPack: EditText
    private lateinit var edGlassBottle: EditText
    private lateinit var edGeneralPlastic: EditText
    private lateinit var edGeneralPaper: EditText
    private lateinit var edPlasticBag: EditText
    private lateinit var edCandles: EditText
    private lateinit var edSlippers: EditText

    // Camera and Gallery buttons for each category
    private lateinit var btnCameraWetOrganic: ImageButton
    private lateinit var btnCameraPet: ImageButton
    private lateinit var btnCameraAluminiumCan: ImageButton
    private lateinit var btnCameraTerraPack: ImageButton
    private lateinit var btnCameraGlassBottle: ImageButton
    private lateinit var btnCameraGeneralPlastic: ImageButton
    private lateinit var btnCameraGeneralPaper: ImageButton
    private lateinit var btnCameraPlasticBag: ImageButton
    private lateinit var btnCameraCandles: ImageButton
    private lateinit var btnCameraSlippers: ImageButton

    private lateinit var btnInput: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_data)

        // Initialize EditTexts
        initializeEditTexts()

        // Initialize Camera Buttons
        initializeCameraButtons()

        // Input Button
        btnInput = findViewById(R.id.btnInput)
        btnInput.setOnClickListener {
            uploadWasteData()
        }
    }

    private fun initializeEditTexts() {
        edWetOrganic = findViewById(R.id.edWetOrganic)
        edPet = findViewById(R.id.edPet)
        edAluminiumCan = findViewById(R.id.edAlumuniumCan)
        edTerraPack = findViewById(R.id.edTerraPack)
        edGlassBottle = findViewById(R.id.edGlassBottle)
        edGeneralPlastic = findViewById(R.id.edGeneralPlastic)
        edGeneralPaper = findViewById(R.id.edGeneralPaper)
        edPlasticBag = findViewById(R.id.edPlasticBag)
        edCandles = findViewById(R.id.edCandles)
        edSlippers = findViewById(R.id.edSlippers)
    }

    private fun initializeCameraButtons() {
        // Camera buttons initialization
        btnCameraWetOrganic = findViewById(R.id.btnCameraWetOrganic)
        btnCameraPet = findViewById(R.id.btnCameraPet)
        btnCameraAluminiumCan = findViewById(R.id.btnCameraAlumuniumCan)
        btnCameraTerraPack = findViewById(R.id.btnCameraTerraPack)
        btnCameraGlassBottle = findViewById(R.id.btnCameraGlassBottle)
        btnCameraGeneralPlastic = findViewById(R.id.btnCameraGeneralPlastic)
        btnCameraGeneralPaper = findViewById(R.id.btnCameraGeneralPaper)
        btnCameraPlasticBag = findViewById(R.id.btnCameraPlasticBag)
        btnCameraCandles = findViewById(R.id.btnCameraCandles)
        btnCameraSlippers = findViewById(R.id.btnCameraSlippers)

        // Set click listeners for camera buttons
        val cameraLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                currentPhotoUri?.let { uri ->
                    currentPhotoFile = File(uri.path ?: "")
                    // You can add code here to display the captured image if needed
                }
            }
        }

        // Example for one camera button (repeat for others)
        btnCameraWetOrganic.setOnClickListener {
            if (checkCameraPermission()) {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                // Create a temporary file for the photo
                currentPhotoFile = createTempImageFile()
                currentPhotoUri = Uri.fromFile(currentPhotoFile)
                intent.putExtra(MediaStore.EXTRA_OUTPUT, currentPhotoUri)
                cameraLauncher.launch(intent)
            }
        }
    }

    private fun uploadWasteData() {
        // Validate and prepare data for each category
        val wasteCategories = listOf(
            Pair("Wet Organic", edWetOrganic.text.toString()),
            Pair("PET", edPet.text.toString()),
            Pair("Aluminium Can", edAluminiumCan.text.toString()),
            Pair("Terra Pack", edTerraPack.text.toString()),
            Pair("Glass Bottle", edGlassBottle.text.toString()),
            Pair("General Plastic", edGeneralPlastic.text.toString()),
            Pair("General Paper", edGeneralPaper.text.toString()),
            Pair("Plastic Bag", edPlasticBag.text.toString()),
            Pair("Candles", edCandles.text.toString()),
            Pair("Slippers", edSlippers.text.toString())
        )

        // You would typically have a way to map category names to their IDs
        val categoryIdMap = mapOf(
            "Wet Organic" to 1,
            "PET" to 2,
            "Aluminium Can" to 3,
            "Terra Pack" to 4,
            "Glass Bottle" to 5,
            "General Plastic" to 6,
            "General Paper" to 7,
            "Plastic Bag" to 8,
            "Candles" to 9,
            "Slippers" to 10
        )

        // Department ID (you might want to get this dynamically)
        val departmentId = 1

        // Upload each category with non-zero weight
        wasteCategories.forEach { (categoryName, weightStr) ->
            val weight = weightStr.toFloatOrNull()
            if (weight != null && weight > 0) {
                val categoryId = categoryIdMap[categoryName]
                categoryId?.let { id ->
                    // Prepare photo if available
                    val photoPart = currentPhotoFile?.let { file ->
                        val requestBody = file.asRequestBody("image/*".toMediaTypeOrNull())
                        MultipartBody.Part.createFormData("evidence_photo", file.name, requestBody)
                    }

                    // Call API to post waste
                    val apiService = ApiConfig.getApiService()
                    apiService.postWaste(
                        categoryId = id,
                        weightKg = weight,
                        departmentId = departmentId,
                        evidencePhoto = photoPart,
                        token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwicm9sZSI6ImFkbWluIiwiaWF0IjoxNzMzNTgwMjE5LCJleHAiOjE3MzM1ODc0MTl9.Upy9XKAUNeeSosTTec0JyIxX8BNXJIhM7Odi9r9YdA4"
                    ).enqueue(object : Callback<WasteResponse> {
                        override fun onResponse(
                            call: Call<WasteResponse>,
                            response: Response<WasteResponse>
                        ) {
                            if (response.isSuccessful) {
                                Toast.makeText(
                                    this@NewDataActivity,
                                    "Uploaded $categoryName successfully",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                Toast.makeText(
                                    this@NewDataActivity,
                                    "Failed to upload $categoryName",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        override fun onFailure(call: Call<WasteResponse>, t: Throwable) {
                            Toast.makeText(
                                this@NewDataActivity,
                                "Network error: ${t.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    })
                }
            }
        }
    }

    private fun checkCameraPermission(): Boolean {
        return if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_REQUEST_CODE
            )
            false
        } else {
            true
        }
    }

    private fun createTempImageFile(): File {
        val timeStamp = System.currentTimeMillis().toString()
        val storageDir = getExternalFilesDir(null)
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        )
    }

    companion object {
        private const val CAMERA_PERMISSION_REQUEST_CODE = 100
    }
}