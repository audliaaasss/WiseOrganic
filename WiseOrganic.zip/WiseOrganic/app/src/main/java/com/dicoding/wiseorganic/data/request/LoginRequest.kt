package com.dicoding.wiseorganic.data.request

data class LoginRequest(
    val username: String,
    val password: String
)