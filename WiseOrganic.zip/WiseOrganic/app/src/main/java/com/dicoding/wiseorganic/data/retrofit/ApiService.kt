package com.dicoding.wiseorganic.data.retrofit

import com.dicoding.wiseorganic.data.response.WasteResponse
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    @GET("waste/{id}")
    fun getWasteDetail(
        @Path("id") id: Int
    ): Call<WasteResponse>

    @GET("waste")
    fun getAllWaste(
    ): Call<WasteResponse>

    @FormUrlEncoded
    @POST("waste-records")
    fun postWaste(
        @Header("Authorization") token: String,
        @Field("evidence_photo") evidencePhoto: MultipartBody.Part?,
        @Field("category_id") categoryId: Int,
        @Field("weight_kg") weightKg: Number,
        @Field("department_id") departmentId: Int
    ): Call<WasteResponse>
}