package com.dicoding.wiseorganic.data.response

import android.provider.ContactsContract.Contacts.Photo
import com.google.gson.annotations.SerializedName
import java.util.Date

data class WasteResponse(

	@field:SerializedName("data")
	val data: List<DataItem>,

	@field:SerializedName("success")
	val success: Boolean,

	@field:SerializedName("message")
	val message: String
)

data class Departement(

	@field:SerializedName("departement_description")
	val departementDescription: String,

	@field:SerializedName("departement_name")
	val departementName: String
)

data class DataItem(

	@field:SerializedName("evidence_photo")
	val evidencePhoto: Photo,

	@field:SerializedName("createdAt")
	val createdAt: Date,

	@field:SerializedName("departement")
	val departement: Departement,

	@field:SerializedName("category_id")
	val categoryId: Int,

	@field:SerializedName("weight_kg")
	val weightKg: Number,

	@field:SerializedName("id")
	val id: Int,

	@field:SerializedName("category")
	val category: Category,

	@field:SerializedName("departement_id")
	val departementId: Int,

	@field:SerializedName("updatedAt")
	val updatedAt: Date
)

data class Category(

	@field:SerializedName("category_description")
	val categoryDescription: String,

	@field:SerializedName("category_name")
	val categoryName: String
)
